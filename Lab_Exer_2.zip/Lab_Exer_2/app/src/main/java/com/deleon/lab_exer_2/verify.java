package com.deleon.lab_exer_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class verify extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
    }

    public void veriButton(View view){
        SharedPreferences sp = getSharedPreferences("data1.txt", MODE_PRIVATE);
        String veriText = ((EditText)findViewById(R.id.verification)).getText().toString();
        boolean test = false;
        for(int i = 1; i <= 8; i++){
            if(sp.getString("schl" + i, null).equals(veriText)){
                Toast.makeText(this, "School is competing in UAAP",Toast.LENGTH_LONG).show();
                test=true;
            }
        }
        if (test == false){
            Toast.makeText(this, "School is not part of UAAP", Toast.LENGTH_SHORT).show();
        }
    }
}
