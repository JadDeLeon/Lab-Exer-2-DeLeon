package com.deleon.lab_exer_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sp;
    SharedPreferences.Editor edit;
    EditText s1, s2, s3, s4, s5, s6, s7, s8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s1 = findViewById(R.id.schl1);
        s2 = findViewById(R.id.schl2);
        s3 = findViewById(R.id.schl3);
        s4 = findViewById(R.id.schl4);
        s5 = findViewById(R.id.schl5);
        s6 = findViewById(R.id.schl6);
        s7 = findViewById(R.id.schl7);
        s8 = findViewById(R.id.schl8);
    }

    protected void savePreference(){
        sp = getSharedPreferences("data1.txt", MODE_PRIVATE);
        edit = sp.edit();
    }

    public void saveData(View view) {
        savePreference();
        edit.putString("schl1", s1.getText().toString());
        edit.putString("schl2", s2.getText().toString());
        edit.putString("schl3", s3.getText().toString());
        edit.putString("schl4", s4.getText().toString());
        edit.putString("schl5", s5.getText().toString());
        edit.putString("schl6", s6.getText().toString());
        edit.putString("schl7", s7.getText().toString());
        edit.putString("schl8", s8.getText().toString());

        edit.commit();
        Toast.makeText(this,"data stored", Toast.LENGTH_LONG).show();
    }

    public void nextPage(View view) {
        Intent intent = new Intent(MainActivity.this, verify.class);
        startActivity(intent);
    }
}
